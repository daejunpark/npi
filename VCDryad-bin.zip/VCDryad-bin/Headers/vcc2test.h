//-----------------------------------------------------------------------------
//
// Copyright (C) Microsoft Corporation.  All Rights Reserved.
//
//-----------------------------------------------------------------------------
#include "vcc.h"

void *malloc(unsigned __int64);
void free(void *p);
#define NULL ((void*)0)
