void __VERIFIER_assert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}

int __VERIFIER_nondet_int();


void foo(int d) {
  int x, y, k, z = 1;
  int c;
  int input;
  L1:
  while (z < k) {
    z = 2 * z; 
  }
  __VERIFIER_assert(z>=1);

  L2:
  while (x > 0 && y > 0) {
    c = __VERIFIER_nondet_int();
    if (c) {
      P1:
      x = x - d;
      y = __VERIFIER_nondet_int();
      z = z - 1;
    } else {
      y = y - d;
    }
  }
}

int main()
{
  int d;
  foo(d);
}
