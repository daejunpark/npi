// ==++==
// 
//   
// 
// ==--==
// Warning: Automatically generated file. DO NOT EDIT
// Generated at Dienstag, 5. Juli 2011 11:26:45

using System.Reflection;
[assembly: AssemblyVersion("2.2.30705.1126")]
[assembly: AssemblyFileVersion("2.2.30705.1126")]

